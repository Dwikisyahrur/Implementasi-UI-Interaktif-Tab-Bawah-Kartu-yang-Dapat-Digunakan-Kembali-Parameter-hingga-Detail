import React from 'react';
import { View, Text, Image, TouchableOpacity, ScrollView } from 'react-native';
import { useRoute } from '@react-navigation/native';

export default function ExploreScreen(){
  const route = useRoute();
  const destination = route.params?.destination;

  if(!destination){
    return (
      <ScrollView style={{flex:1, padding:20}}>
        <Text style={{fontSize:18, fontWeight:'600'}}>Explore</Text>
        <Text style={{marginTop:10}}>Pilih destinasi dari Home untuk melihat detail.</Text>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={{flex:1, padding:20}}>
      <Image source={{uri: destination.image}} style={{width:'100%', height:260, borderRadius:16}} />
      <Text style={{fontSize:28, fontWeight:'700', marginTop:12}}>{destination.name}</Text>
      <Text style={{color:'#6b7280', marginTop:4}}>{destination.country}</Text>
      <Text style={{fontSize:18, fontWeight:'600', marginTop:10}}>{destination.price}</Text>
      <TouchableOpacity style={{marginTop:18, backgroundColor:'#F97316', padding:14, borderRadius:12}}>
        <Text style={{color:'#fff', textAlign:'center', fontWeight:'700'}}>Book Now</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
