import React from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import DestinationCard from '../components/DestinationCard';
import { useNavigation } from '@react-navigation/native';

export default function HomeScreen(){
  const navigation = useNavigation();
  const destinations = [
    {
      id:1,
      country:'Indonesia',
      name:'Labuan Bajo',
      price:'$4.000/pax',
      rating:5.0,
      image:'https://images.unsplash.com/photo-1565939752324-27f3e66e4d4c'
    },
    {
      id:2,
      country:'Italy',
      name:'Venezia',
      price:'$3.500/pax',
      rating:4.7,
      image:'https://images.unsplash.com/photo-1543340900-5b7b4c3c3e9e'
    }
  ];

  return (
    <ScrollView style={{flex:1, backgroundColor:'#F7F5F0', padding:20}}>
      <Text style={{color:'#6b7280', fontSize:16}}>Hi,</Text>
      <Text style={{fontSize:32, fontWeight:'700', marginBottom:12}}>Haikal</Text>

      <View style={{backgroundColor:'#F97316', padding:18, borderRadius:16, marginBottom:18}}>
        <Text style={{color:'#fff', fontSize:22, fontWeight:'700'}}>Plan Your{'
'}Summer!</Text>
      </View>

      <TextInput placeholder="Search destination..." style={{backgroundColor:'#F3F4F6', padding:12, borderRadius:12, marginBottom:18}} />

      <Text style={{fontSize:16, fontWeight:'600', marginBottom:10}}>Popular Destination</Text>

      {destinations.map(d => (
        <DestinationCard key={d.id} data={d} onPress={() => navigation.navigate('Explore', { destination: d })} />
      ))}
    </ScrollView>
  );
}
