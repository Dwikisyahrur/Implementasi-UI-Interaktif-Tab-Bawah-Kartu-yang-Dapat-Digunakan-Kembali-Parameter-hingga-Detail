import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function DestinationCard({data, onPress}){
  return (
    <TouchableOpacity onPress={onPress} style={{marginBottom:18}}>
      <Image source={{uri: data.image}} style={{width:'100%', height:180, borderRadius:14}} />
      <View style={{position:'absolute', left:12, bottom:12}}>
        <Text style={{color:'#fff', fontWeight:'700', fontSize:18}}>{data.name}</Text>
        <Text style={{color:'#fff'}}>{data.country}</Text>
        <Text style={{color:'#fff', marginTop:6}}>{data.price}</Text>
      </View>
      <View style={{position:'absolute', right:12, top:12, backgroundColor:'rgba(0,0,0,0.35)', padding:6, borderRadius:10, flexDirection:'row', alignItems:'center'}}>
        <Ionicons name="star" size={14} color="#FFD700" />
        <Text style={{color:'#fff', marginLeft:6}}>{data.rating}</Text>
      </View>
    </TouchableOpacity>
  );
}
