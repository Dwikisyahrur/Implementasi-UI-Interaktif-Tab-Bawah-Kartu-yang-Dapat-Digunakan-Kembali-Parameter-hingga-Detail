import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from '../screens/HomeScreen';
import ExploreScreen from '../screens/ExploreScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

export default function BottomTabs(){
  return (
    <Tab.Navigator
      screenOptions={({route})=>({
        headerShown:false,
        tabBarShowLabel:false,
        tabBarStyle:{ backgroundColor: '#0f1724', borderTopWidth:0, height:70 },
        tabBarIcon: ({focused}) => {
          let name='home-outline';
          if(route.name==='Home') name = focused? 'home' : 'home-outline';
          if(route.name==='Explore') name = focused? 'grid' : 'grid-outline';
          if(route.name==='Profile') name = focused? 'person' : 'person-outline';
          return <Ionicons name={name} size={24} color={focused? '#fff' : '#9ca3af'} />;
        }
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Explore" component={ExploreScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
